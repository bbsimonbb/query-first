﻿using System;

namespace $rootnamespace$
{
	[Serializable]
	public partial class $safeitemrootname$
	{
		// Partial class extends the generated results class
		// Serializable by default, but you can change this here
		// Changing the default namespace is not currently supported,
		// unless you're happy to manually add a logical name for the 
		// corresponding sql embedded resource, as described here...
		// http://blogs.msdn.com/b/jrock/archive/2006/09/20/763397.aspx
		// Put your methods here :-)
	}
}
