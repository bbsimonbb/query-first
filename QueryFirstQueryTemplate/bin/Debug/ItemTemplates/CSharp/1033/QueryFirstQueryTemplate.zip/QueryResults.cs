﻿using System;

namespace $rootnamespace$
{
	[Serializable]
	public partial class $safeitemrootname$
	{
		// Partial class extends the generated results class
		// Serializable by default, but you can change this here		
		// Put your methods here :-)
		internal void OnLoad()
		{
		}       
	}
}
